//Write a JavaScript function that accepts a number as a parameter and check the number is prime or not

//function test_prime(n){
  //if (n===1) {
    //return false;
  //}else if(n === 2){
    //return true;
  //}else{
    //for(let i = 2; i < n; i++){
      //if(n % i === 0){
        //return false;
     // }
    //}
    //return true;  
  //}
//}

//for (let i = 1; i<=20; i++){
  //console.log('Number ',  i, ' prime: ', test_prime(i));
//}
