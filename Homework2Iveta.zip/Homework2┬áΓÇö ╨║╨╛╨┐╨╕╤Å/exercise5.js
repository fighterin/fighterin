//5. Write a JavaScript program that accept three integers and display the larger

//function maxThree(x, y, z) 
 //{
   //let maximum;
  //if (x > y)
  //{
    //maximum = x;
  //} else
  //{
   // maximum = y;
  //}
  //if (z > maximum) 
  //{
   // maximum = z;
  //}
 // return maximum;
//}

//console.log(maxThree(5,3,2));
//console.log(maxThree(2,3,1));
//console.log(maxThree(2,1,10));
//console.log(maxThree(1,0,1));

