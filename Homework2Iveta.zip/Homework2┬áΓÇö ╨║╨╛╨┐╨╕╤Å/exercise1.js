// Write a JavaScript function which accepts an argument and returns the type.



function getType (arg){
  return typeof(arg);
}
let num = getType(10);
console.log('Type: ', num);

let string = getType('10');
console.log('Type: ', string);