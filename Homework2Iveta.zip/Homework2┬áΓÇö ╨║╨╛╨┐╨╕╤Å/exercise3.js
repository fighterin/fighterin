//3. Write a JavaScript function to convert an amount to small coins.
// Coins 1,2,5,10,20,50

//function amountTocoins(amount, coins) 
//{
 //if (amount === 0) 
  //{
     //return [];
   //} 
 //else
   //{
     //if (amount >= coins[0]) 
       //{
        //left = (amount - coins[0]);
       // return [coins[0]].concat( amountTocoins(left, coins) );
       // } 
      //else
       //{
       // coins.shift();
        // return amountTocoins(amount, coins);
        //}
   //}
//} 
//console.log(amountTocoins(88, [50, 20, 10, 5, 2, 1]))